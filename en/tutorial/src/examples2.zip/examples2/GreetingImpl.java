package examples2;

public class GreetingImpl implements Greeting {

	public String greet() {
		return "2 Hello World!";
	}
}
