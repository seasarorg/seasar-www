package examples2;

public class Greeting2Impl implements Greeting {

	public String greet() {
		return "2b Hello World!";
	}
}
