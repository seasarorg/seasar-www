package examples2;

public class GreetingClient2Impl implements GreetingClient {

    private Greeting greeting;

    public void setGreeting(Greeting greeting) {
        this.greeting = greeting;
    }
    
    public void execute() {
        System.err.println(greeting.greet());
    }
}
