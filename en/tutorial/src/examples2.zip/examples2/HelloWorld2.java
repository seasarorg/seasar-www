package examples2;

public class HelloWorld2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Greeting greeting = new GreetingImpl();
		GreetingClient greetingClient = new GreetingClientImpl();
		greetingClient.setGreeting(greeting);
		greetingClient.execute();

		greeting = new Greeting2Impl();
		greetingClient = new GreetingClient2Impl();
		greetingClient.setGreeting(greeting);
		greetingClient.execute();
	}

}
