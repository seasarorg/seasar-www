package examples2;

public interface Greeting {
    String greet();
}
