package examples2;

public interface GreetingClient {
  void setGreeting(Greeting greeting);
  void execute();
}
