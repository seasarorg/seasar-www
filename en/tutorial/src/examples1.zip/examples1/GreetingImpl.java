package examples1;

public class GreetingImpl implements Greeting {

	public void greet() {
		System.out.println("1 Hello World!");
	}
}
