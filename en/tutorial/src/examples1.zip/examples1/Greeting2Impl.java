package examples1;

public class Greeting2Impl implements Greeting {

	public void greet() {
		System.out.println("1b Hello World!");
	}
}
