package examples1;

public interface Greeting {
	public void greet();
}
