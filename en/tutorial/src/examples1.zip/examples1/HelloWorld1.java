package examples1;

public class HelloWorld1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Greeting greeting = new GreetingImpl();
		greeting.greet();
		
		greeting = new Greeting2Impl();
		greeting.greet();

	}

}
