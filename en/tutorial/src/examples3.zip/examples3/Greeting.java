package examples3;

public interface Greeting {
    String greet();
}
