package examples3;

public class GreetingImpl implements Greeting {

	public String greet() {
		return "3 Hello World!";
	}

}
