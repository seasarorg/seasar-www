package examples3;

public interface GreetingClient {
	void execute();
}
