package examples4;

import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.S2ContainerFactory;
import org.seasar.framework.util.ResourceNotFoundRuntimeException;

public class HelloWorld4 {
    private static final String CONFIGURE_PATH = "Greeting.dicon";
 
    public static void main(String[] args) {
    	try {
    		S2Container container = S2ContainerFactory.create(CONFIGURE_PATH);
    		
    		GreetingClient greetingClient
		 = (GreetingClient)container.getComponent("greetingClient");
    		greetingClient.execute();
    	} catch (ResourceNotFoundRuntimeException e){
    		System.out.println("Configuration file \"" + CONFIGURE_PATH + "\" not found.");
    	}
    }
}
