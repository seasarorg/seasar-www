package examples4;

public class GreetingImpl implements Greeting {

	public String greet() {
		return "4 Hello World!";
	}

}
