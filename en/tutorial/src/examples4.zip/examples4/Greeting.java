package examples4;

public interface Greeting {
    String greet();
}
