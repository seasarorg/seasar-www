package examples4;

public class Greeting2Impl implements Greeting {

	public String greet() {
		return "4b Hello World!";
	}

}
