package examples4;

public interface GreetingClient {
	void execute();
}
