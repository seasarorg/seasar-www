package examples5.impl;

import examples5.Greeting;

public class GreetingImpl implements Greeting {

	public String greet() {
		return "5 Hello World!";
	}

}
