package examples5.impl;

import examples5.Greeting;
import examples5.GreetingClient;

public class GreetingClientImpl implements GreetingClient {

    private Greeting greeting;

    public void setGreeting(Greeting greeting) {
        this.greeting = greeting;
    }
    
    public void execute() {
        System.out.println(greeting.greet());
    }
}
