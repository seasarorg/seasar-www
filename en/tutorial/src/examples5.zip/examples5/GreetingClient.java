package examples5;

public interface GreetingClient {
	void execute();
}
