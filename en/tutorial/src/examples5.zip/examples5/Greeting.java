package examples5;

public interface Greeting {
    String greet();
}
