package examples5.main;

import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.S2ContainerFactory;
import org.seasar.framework.util.ResourceNotFoundRuntimeException;

import examples5.GreetingClient;

public class HelloWorld5 {
    private static final String CONFIGURE_PATH = "dicon/Greeting.dicon";
    
    public static void main(String[] args) {
    	try {
    		S2Container container = S2ContainerFactory.create(CONFIGURE_PATH);
            container.init();	// add to initialize components
            try {
            	GreetingClient greetingClient = (GreetingClient)
            	container.getComponent("greetingClient");
            	greetingClient.execute();
        	} finally {
        		container.destroy();
        	}
    	} catch (ResourceNotFoundRuntimeException e){
    		System.out.println("Configuration file \"" + CONFIGURE_PATH + "\" not found.");
    	}
    }
}
