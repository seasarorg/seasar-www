package examples0;

public class HelloWorld0 {

	public static void main(String[] args) {
		System.out.println("0 Hello World!");
	}
}
