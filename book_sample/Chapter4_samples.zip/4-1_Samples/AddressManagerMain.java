/**
 * ���C���N���X
 */
package examples.AddressManager;

import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.S2ContainerFactory;

public class AddressManagerMain {
	private static final String PATH =
        "examples/AddressManager/AddressManager.dicon";
    public static void main(String[] args) {
        S2Container container = S2ContainerFactory.create(PATH);
        container.init();
        AddressManager addressManager =
            (AddressManager) container.getComponent(AddressManager.class);

        // �f�[�^�t�@�C���ǂݍ���
        addressManager.load();

        // �o��
        addressManager.printAll();
    }
}
