/**
 * CSV�t�@�C������f�[�^��ǂݍ���
 *
 */
package examples.AddressManager;

import java.util.ArrayList;
import java.io.*;

public class CsvFileReader {

	public CsvFileReader(){
	}
	public ArrayList readFile(String fileName){
		ArrayList lst = new ArrayList();
		try{
			BufferedReader br = 
				new BufferedReader(new FileReader(fileName));
			while(br.ready()){
				String msg[] = br.readLine().split(",");
				AddressData ad = new AddressData();
				ad.setNameKanji(msg[0]);
				ad.setNameKana(msg[1]);
				ad.setZipCode(msg[2]);
				ad.setAddress(msg[3]);
				ad.setTel(msg[4]);
				lst.add((AddressData)ad);
			}
			br.close();		
		} catch(Exception e){
			e.printStackTrace();
		} 
		return lst;
	}
}
