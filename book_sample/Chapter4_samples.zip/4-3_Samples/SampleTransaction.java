
package sample.transaction;

import java.sql.SQLException;


public interface SampleTransaction {

	public void logicCommit(Employee employee) throws SQLException;
	public void logicError(Employee employee) throws SQLException;
	public void databaseError(Employee employee) throws SQLException;
	
}
