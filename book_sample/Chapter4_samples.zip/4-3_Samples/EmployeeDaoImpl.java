
package sample.transaction;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

public class EmployeeDaoImpl implements EmployeeDao {
	
	private DataSource dataSource_;
	
	public EmployeeDaoImpl(DataSource dataSource) {
		dataSource_ = dataSource;
	}

	public void Insert(Employee employee) throws SQLException {
		
		int rs = 0;
		Connection con = dataSource_.getConnection();
		System.out.println("DaoImpl: �o�^�����f�[�^�͈ȉ��̒ʂ�ł�");
		System.out.println(employee.toString());
		
		try {
			PreparedStatement ps = con.prepareStatement(
			"INSERT INTO emp2 VALUES(?,?,null)");
			try {
				ps.setLong(1, employee.getEmpno());
				ps.setString(2,employee.getEname());
				rs = ps.executeUpdate();
			}finally{
				ps.close();
			}
		}finally{
			con.close();
		}
		
		System.out.println("DaoImpl: �f�[�^���o�^����܂���");
		System.out.println("DaoImpl: �����F" + rs);
	}

	public void delete(Employee employee) throws SQLException {
		
		int rs = 0;
		Connection con = dataSource_.getConnection();
		System.out.println("DaoImpl: �폜�����f�[�^�͈ȉ��̒ʂ�ł�");
		System.out.println(employee.toString());
		
		try {
			PreparedStatement ps = con.prepareStatement(
			"DELETE FROM emp2 WHERE empno = ?");
			try {
				ps.setLong(1, employee.getEmpno());
				rs = ps.executeUpdate();
			}finally{
				ps.close();
			}
		}finally{
			con.close();
		}
		
		System.out.println("DaoImpl: �f�[�^���폜����܂���");
		System.out.println("DaoImpl: �����F" + rs);
	}
	
	public int select(Employee employee) throws SQLException {
		
		Connection con = dataSource_.getConnection();
		
		int lc = 0;
		try {
			PreparedStatement ps = con.prepareStatement(
				"SELECT count(*) FROM emp2 WHERE empno = ?");
			try {
				ps.setLong(1, employee.getEmpno());
				ResultSet rs = ps.executeQuery();
				try {
					if (rs.next()) {
						lc = rs.getInt(1);
					}
				} finally {
					rs.close();
				}
			} finally {
				ps.close();
			}
		} finally {
			con.close();
		}
		return lc;
	}
}
