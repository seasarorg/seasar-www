
package sample.transaction;

import java.sql.SQLException;

public interface EmployeeDao {

	public void Insert(Employee employee) throws SQLException;
	public int select(Employee employee) throws SQLException;
	public void delete(Employee employee) throws SQLException;
	
}
