/*
 * Created on 2005/09/24
 */
package sample.transaction;

import java.io.Serializable;

public class Employee implements Serializable {


	private long empno;
	private String ename;

    public Employee() {
    
    }

    public Employee(long empno, String ename) {
        this.empno = empno;
        this.ename = ename;
    }

	public long getEmpno() {
		return this.empno;
	}

	public void setEmpno(long empno) {
		this.empno = empno;
	}

	public java.lang.String getEname() {
		return this.ename;
	}

	public void setEname(java.lang.String ename) {
		this.ename = ename;
	}

	public boolean equals(Object other) {
		if (!(other instanceof Employee))
			return false;
		Employee castOther = (Employee) other;
		return this.getEmpno() == castOther.getEmpno();
	}

	public String toString() {
		StringBuffer buf = new StringBuffer();
		buf.append("emp:EMPNO, ENAME ").append("{");
		buf.append(this.empno).append(", ");
		buf.append(this.ename).append("}");
		return new String(buf);
	}

	public int hashCode() {
		return (int) this.getEmpno();
	}
}