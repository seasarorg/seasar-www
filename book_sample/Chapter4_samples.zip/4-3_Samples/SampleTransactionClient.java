package sample.transaction;

import java.sql.SQLException;

import org.seasar.framework.container.S2Container;
import org.seasar.framework.container.factory.S2ContainerFactory;

public class SampleTransactionClient {

	private static final String PATH =
		"sample/transaction/SampleTransaction.dicon";
		
	public static void main(String[] args) {
		S2Container container = S2ContainerFactory.create(PATH);
		container.init();
		
		try{
		  SampleTransaction tr =
		  	(SampleTransaction) container.getComponent(SampleTransaction.class);
		
		  int id_a = 9901;
		  Employee newEmployee = new Employee(id_a,"foo");  
		  /* ����ɃR�~�b�g����� */
//		  tr.logicCommit(newEmployee);
	
		  int id_b = 9902;
		  Employee newEmployee_b = new Employee(id_b,"bar");  
		  /* �������W�b�N�ňُ킪�������� */
//		  tr.logicError(newEmployee_b);
		
		  /* �f�[�^�x�[�X�o�^���Ɉُ킪�������� */
		  int id_c = 9903;
		  Employee newEmployee_c = new Employee(id_c,"hoge");    
		  tr.databaseError(newEmployee_c);
		  
		}catch(SQLException ex){
			ex.printStackTrace();
		}catch(RuntimeException e){
            System.out.println(e.getMessage());
		}finally{
			container.destroy();
		}
		 

	}
	
	
}
