package jsf.converter;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;

public class StringBufferConverter implements Converter {

    public StringBufferConverter() {
    }

    public Object getAsObject(FacesContext context, UIComponent component, String str) throws ConverterException {
        if (str == null) {
            return null;
        }
        return new StringBuffer(str);
    }

    public String getAsString(FacesContext context, UIComponent component, Object object) throws ConverterException {
        if (object == null) {
            return null;
        }
        return object.toString();
    }

}
