package jsf.logic;

import jsf.dto.CalculateDto;
import jsf.dto.ResultDto;

public interface AddLogic {
	public ResultDto calculate(CalculateDto addDto);
}
