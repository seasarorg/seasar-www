package jsf.logic.impl;

import jsf.dto.CalculateDto;
import jsf.dto.ResultDto;
import jsf.logic.AddLogic;

public class AddLogicImpl implements AddLogic {
    
	public ResultDto calculate(CalculateDto dto) {
		int result = dto.getArg1() + dto.getArg2();
		
		ResultDto resultDto = new ResultDto();
		resultDto.setResult(result);
		return resultDto;
	}

}
