package jsf.dto;

import java.io.Serializable;

public class SelectManyCheckboxDto implements Serializable {

    private String[] value1 = {"2"};

    private Object[] value2 = {"1", "3"};

    private int[] value3;

    public String[] getValue1() {
        return value1;
    }

    public void setValue1(String[] value1) {
        this.value1 = value1;
    }

    public Object[] getValue2() {
        return value2;
    }

    public void setValue2(Object[] value2) {
        this.value2 = value2;
    }

    public int[] getValue3() {
        return value3;
    }

    public void setValue3(int[] value3) {
        this.value3 = value3;
    }
}