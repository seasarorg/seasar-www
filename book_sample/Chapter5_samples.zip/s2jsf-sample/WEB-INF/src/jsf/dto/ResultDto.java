package jsf.dto;

import java.io.Serializable;

public class ResultDto implements Serializable {

	private int result;
	
	public ResultDto() {
	}
	
	public int getResult() {
		return result;
	}
	
	public void setResult(int result) {
		this.result = result;
	}
}
