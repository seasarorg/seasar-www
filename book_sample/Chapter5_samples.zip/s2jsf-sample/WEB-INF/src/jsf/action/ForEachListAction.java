package jsf.action;

public interface ForEachListAction {

	public String update();
	
	public String addRow();
}
