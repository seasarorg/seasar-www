package jsf.action;


public interface AddAction {
    public String calculate();
}
