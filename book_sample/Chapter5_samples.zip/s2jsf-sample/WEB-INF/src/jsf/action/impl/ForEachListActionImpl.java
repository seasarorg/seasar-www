package jsf.action.impl;

import java.util.Iterator;
import java.util.List;

import jsf.action.ForEachListAction;
import jsf.dto.ForEachDto;

public class ForEachListActionImpl implements ForEachListAction {

	private List forEachDtoList;
	
	public void setForEachDtoList(List forEachDtoList) {
		this.forEachDtoList = forEachDtoList;
	}
	
	public String update() {
		for (Iterator i = forEachDtoList.iterator(); i.hasNext(); ) {
			ForEachDto dto = (ForEachDto) i.next();
			if (dto.isDelete()) {
				i.remove();
			}
		}
		return null;
	}

	public String addRow() {
		forEachDtoList.add(new ForEachDto());
		return null;
	}
}