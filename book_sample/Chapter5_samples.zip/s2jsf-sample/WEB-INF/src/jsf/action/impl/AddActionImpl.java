package jsf.action.impl;

import jsf.action.AddAction;
import jsf.dto.CalculateDto;
import jsf.dto.ResultDto;
import jsf.logic.AddLogic;

public class AddActionImpl implements AddAction {

    private CalculateDto calculateDto;
    private ResultDto resultDto;
    private AddLogic addLogic;

    public void setCalculateDto(CalculateDto dto) {
        this.calculateDto = dto;
    }

    public void setAddLogic(AddLogic addLogic) {
        this.addLogic = addLogic;
    }
    
    public ResultDto getResultDto() {
        return resultDto;
    }

    public String calculate() {
        resultDto = addLogic.calculate(calculateDto);
        return "result";
    }

}
