package jsf.action;

public interface ForEachResultInitAction {

	public String initialize();
}
