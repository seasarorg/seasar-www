package jsf.entity;

import java.io.Serializable;

public class Department implements Serializable {

    private int deptno;

    private String dname;

    public int getDeptno() {
        return this.deptno;
    }

    public void setDeptno(int deptno) {
        this.deptno = deptno;
    }

    public String getDname() {
        return this.dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }
}
