insert into class values(1,'1-A','Seasar1');
insert into class values(2,'1-B','Seasar2');
insert into class values(3,'1-C','Seasar3');

insert into student values(1,'Student1','05-01',1);
insert into student values(2,'Student2','05-02',1);
insert into student values(3,'Student3','05-03',1);
insert into student values(4,'Student4','05-04',1);
insert into student values(5,'Student5','05-05',2);
insert into student values(6,'Student6','05-06',2);
insert into student values(7,'Student7','05-07',2);
insert into student values(8,'Student8','05-08',3);
insert into student values(9,'Student9','05-09',3);

