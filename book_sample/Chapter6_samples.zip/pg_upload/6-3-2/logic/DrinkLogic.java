package logic;

import java.sql.SQLException;

import model.Drink;

import dao.DrinkDao;
import dao.DrinkDaoImpl;

public class DrinkLogic {
	
	public void addDrink(String name,int price,int quantity,String type){
			
		try{			
			DrinkDao dao = new DrinkDaoImpl();
			
			Drink drink = new Drink();
			drink.setId(1);
			drink.setName(name);
			drink.setPrice(price);
			drink.setQuantity(quantity);
			drink.setType(type);
			
			dao.insert(drink);
			
			dao.close();
			
		}catch(SQLException ex){
			ex.printStackTrace();
		}
		
	}
}
