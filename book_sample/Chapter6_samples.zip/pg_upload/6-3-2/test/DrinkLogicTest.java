package test;

import junit.framework.TestCase;
import logic.DrinkLogic;

public class DrinkLogicTest extends TestCase {

	public DrinkLogicTest(String name) {
		super(name);
	}
	
	public void testDrinkLogic(){
		DrinkLogic logic = new DrinkLogic();
		
		logic.addDrink("�y�v�V�R�[��",140,500,"�y�b�g�{�g��");
		
		
	}

}
